This extension is all about providing the navigation control which is much similar in VIM and other editor.

